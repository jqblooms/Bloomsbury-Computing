// LGDesigner - the drawing surface for Byte Brawlers and Flag Brawlers,
// ported from the original tshirt-designer-module.js in
// jquinney-hue/PythonCourse (the Firebase version of Byte Brawlers).
// Kept faithful on purpose after an earlier rebuild silently dropped parts
// of it. What it carries over:
//   * the garment PNG's alpha channel is the drawing MASK - nothing can be
//     painted outside the shirt/jeans/cap, and the export is a clean cutout
//   * the garment is MULTIPLIED over the paint so fabric folds still show
//   * tools: brush, line, flood fill (bounded by your lines AND the mask),
//     eraser, undo, clear, brush size slider
//   * 16 named colour maps; in "binary" mode a colour is EARNED by typing
//     its 4-bit index (20s timer, keyboard 0/1/backspace, calculator),
//     in "free" mode (Flag Brawlers) swatches are simply clicked
//   * drawOutsideMask: the template is LOCKED and you draw AROUND it - used
//     when an eliminated player finishes a winner's design as a character
// Standalone (no game code in here) so it can be reused unchanged.
(function () {
  'use strict';

  var COLOR_MAPS = [
    { id: 'classic',    name: 'Classic 16', colors: [
      '#000000','#ffffff','#ff2200','#00bb00','#0000ff','#ffff00','#ff00ff','#00ffff',
      '#888888','#cccccc','#ff8800','#9900cc','#00aa88','#aa0000','#0055cc','#ffaa66'
    ]},
    { id: 'pastel',     name: 'Pastel Dream', colors: [
      '#000000','#ffd6e0','#ffc0cb','#ffb3ba','#ffdfba','#ffffba','#baffc9','#bae1ff',
      '#e8baff','#ffbaf6','#c9baff','#bafff0','#fff0ba','#d4f0d4','#f0d4d4','#ffffff'
    ]},
    { id: 'neon',       name: 'Neon City', colors: [
      '#000000','#ff0066','#ff3300','#ff8800','#ffee00','#aaff00','#00ff44','#00ffcc',
      '#00aaff','#0044ff','#aa00ff','#ff00cc','#ff77aa','#77ffcc','#77aaff','#ffffff'
    ]},
    { id: 'sunset',     name: 'Sunset', colors: [
      '#000000','#0d0518','#2a0a2e','#4a1030','#7a1530','#aa2020','#d04020','#e86020',
      '#f08840','#f5aa60','#f8c880','#fae0a0','#fceebb','#fff0cc','#fff8e6','#ffffff'
    ]},
    { id: 'ocean',      name: 'Ocean Depths', colors: [
      '#000000','#020a18','#041830','#063050','#084878','#0a68a0','#1088c8','#20a8e0',
      '#40c0f0','#70d8f8','#a0e8ff','#c0f4ff','#003344','#006699','#0088bb','#e0f8ff'
    ]},
    { id: 'forest',     name: 'Forest', colors: [
      '#000000','#0a0d00','#141e00','#223200','#334d00','#446600','#5a8800','#72aa10',
      '#8acc30','#a0e050','#b8f070','#cef890','#3d1e00','#6b3500','#9a5a00','#d4a060'
    ]},
    { id: 'grayscale',  name: 'Grayscale', colors: [
      '#000000','#111111','#222222','#333333','#444444','#555555','#666666','#777777',
      '#888888','#999999','#aaaaaa','#bbbbbb','#cccccc','#dddddd','#eeeeee','#ffffff'
    ]},
    { id: 'retrocga',   name: 'Retro CGA', colors: [
      '#000000','#0000aa','#00aa00','#00aaaa','#aa0000','#aa00aa','#aa5500','#aaaaaa',
      '#555555','#5555ff','#55ff55','#55ffff','#ff5555','#ff55ff','#ffff55','#ffffff'
    ]},
    { id: 'candy',      name: 'Candy Shop', colors: [
      '#000000','#ff0090','#ff4499','#ff88bb','#ffbbdd','#ff4400','#ff8833','#ffcc66',
      '#ffff99','#99ff33','#55dd00','#00aa00','#0099ff','#0044cc','#6600cc','#ffffff'
    ]},
    { id: 'autumn',     name: 'Autumn', colors: [
      '#000000','#1a0800','#3d1400','#6b2800','#994400','#c86000','#e87c20','#f09a40',
      '#f8b860','#f5d080','#eed8a0','#f0e8b8','#556600','#334400','#223300','#f5f0e0'
    ]},
    { id: 'arctic',     name: 'Arctic', colors: [
      '#000000','#0a1428','#142850','#1e3c78','#285098','#3268b8','#4080cc','#589ae0',
      '#78b4e8','#98ccf0','#b8e4f8','#d8f4ff','#003344','#00556a','#007799','#f0faff'
    ]},
    { id: 'volcano',    name: 'Volcano', colors: [
      '#000000','#1a0000','#3d0000','#6b0000','#990000','#cc1100','#ee2200','#ff5500',
      '#ff7700','#ff9900','#ffbb00','#ffdd00','#ffee44','#fff088','#fff8cc','#ffffff'
    ]},
    { id: 'minecraft',  name: 'Minecraft', colors: [
      '#000000','#ffffff','#9d9d97','#474f52','#8b5a2b','#c8a064','#7cbd1f','#546d28',
      '#5dc5e2','#3c6eb4','#e57540','#d83030','#b045c4','#7033b0','#f0d858','#f5e8a0'
    ]},
    { id: 'rainbow',    name: 'Rainbow', colors: [
      '#000000','#ff0000','#ff4400','#ff8800','#ffcc00','#ffff00','#aaff00','#00ff00',
      '#00ffaa','#00ffff','#00aaff','#0000ff','#4400ff','#8800ff','#cc00ff','#ffffff'
    ]},
    { id: 'gameboy',    name: 'Game Boy', colors: [
      '#000000','#0f380f','#306230','#8bac0f','#9bbc0f','#88a820','#557028','#184028',
      '#082018','#0a2a10','#365020','#607040','#889060','#a0a870','#b8b888','#d0d0b0'
    ]},
    { id: 'synthwave',  name: 'Synthwave', colors: [
      '#000000','#0d0221','#190d4a','#2b0f69','#4a0080','#7a00aa','#aa10cc','#dd40ee',
      '#ff60ff','#ff2266','#ff6600','#ffaa00','#00ffcc','#00aaff','#ffffff','#ffddff'
    ]},
  ];

  var TIMER = 20;
  var STYLE_ID = 'lgd-style';

  function injectStyle() {
    if (document.getElementById(STYLE_ID)) return;
    var s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent =
      '.lgd{font-family:inherit;color:#eef1fb}' +
      '.lgd-toolrow{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:8px;justify-content:center}' +
      '.lgd-tbtn{padding:7px 10px;border-radius:8px;font-size:.8rem;font-weight:700;cursor:pointer;border:1px solid #333e6b;background:#1c2340;color:#9aa3c4}' +
      '.lgd-tbtn.sel{border-color:#4f7cff;background:#21295a;color:#cfe0ff}' +
      '.lgd-tbtn.danger{border-color:#7a3a3a;color:#ff9a9a}' +
      '.lgd-sizewrap{display:flex;align-items:center;gap:5px;font-size:.72rem;color:#9aa3c4}' +
      '.lgd-sizewrap input{width:80px;margin:0;padding:0}' +
      '.lgd-stage{border-radius:10px;border:1px solid #333e6b;display:flex;align-items:center;justify-content:center;overflow:hidden;margin-bottom:10px;' +
        'background-image:linear-gradient(45deg,#1c2340 25%,transparent 25%),linear-gradient(-45deg,#1c2340 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#1c2340 75%),linear-gradient(-45deg,transparent 75%,#1c2340 75%);' +
        'background-size:22px 22px;background-position:0 0,0 11px,11px -11px,-11px 0;background-color:#0e1220}' +
      '.lgd-canvas{max-width:100%;height:auto;display:block;touch-action:none;cursor:crosshair}' +
      '.lgd-card{background:#141a30;border:1px solid #333e6b;border-radius:10px;padding:10px;margin-bottom:10px}' +
      '.lgd-lbl{font-size:.65rem;color:#6d76a0;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px}' +
      '.lgd-select{width:100%;background:#1c2340;color:#eef1fb;border:1px solid #333e6b;border-radius:8px;padding:6px 8px;font-size:.85rem;margin:0}' +
      '.lgd-bits{display:flex;gap:5px;justify-content:center;margin-bottom:6px}' +
      '.lgd-bit{width:34px;height:42px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1.4rem;font-weight:700;font-family:monospace}' +
      '.lgd-bitbtns{display:flex;gap:6px;justify-content:center}' +
      '.lgd-bitbtn{flex:1;max-width:80px;padding:10px 0;background:#1c2340;color:#eef1fb;border:1px solid #333e6b;border-radius:8px;font-size:1.1rem;font-weight:700;font-family:monospace;cursor:pointer}' +
      '.lgd-pal{display:grid;grid-template-columns:repeat(8,1fr);gap:4px}' +
      '.lgd-pal-item{display:flex;flex-direction:column;align-items:center;gap:2px;padding:3px 0;border-radius:6px;cursor:default}' +
      '.lgd-pal-item.free{cursor:pointer}' +
      '.lgd-pal-item.on{background:rgba(79,124,255,.25);outline:1px solid #4f7cff}' +
      '.lgd-pal-sw{width:22px;height:22px;border-radius:5px;border:1px solid rgba(255,255,255,.2)}' +
      '.lgd-pal-n{font-size:.62rem;color:#9aa3c4;font-family:monospace}' +
      '.lgd-calc-disp{background:#1c2340;color:#eef1fb;font-family:monospace;font-size:1.05rem;text-align:right;padding:6px 8px;border-radius:6px;margin-bottom:6px;min-height:2rem;word-break:break-all}' +
      '.lgd-calc-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:4px}' +
      '.lgd-calc-grid button{padding:9px 0;border-radius:6px;font-size:.95rem;font-weight:700;border:none;color:#eef1fb;cursor:pointer}' +
      '.lgd-msg{padding:24px;text-align:center;color:#9aa3c4;font-size:.9rem;line-height:1.5}' +
      '.lgd-need{font-size:.72rem;text-align:center;margin-top:4px;min-height:1em}';
    document.head.appendChild(s);
  }

  function hexToRgb(hex) {
    hex = String(hex).replace('#', '');
    if (hex.length === 3) hex = hex.replace(/(.)/g, '$1$1');
    return { r: parseInt(hex.slice(0, 2), 16), g: parseInt(hex.slice(2, 4), 16), b: parseInt(hex.slice(4, 6), 16) };
  }

  // options:
  //   templateUrl     garment / winner-design image (URL or data URL)
  //   blank           {w,h} instead of a template: a plain white drawable rectangle (flags)
  //   drawOutsideMask lock the template, draw around it (eliminated-player "character" mode)
  //   colourMode      'binary' (default) or 'free'
  //   maxSize         longest side, px (default 480 - phone friendly)
  function create(container, options) {
    options = options || {};
    var el = (typeof container === 'string') ? document.getElementById(container) : container;
    if (!el) return null;
    injectStyle();

    var MAXSIZE = options.maxSize || 480;
    var OUTSIDE = options.drawOutsideMask === true;
    var FREE = options.colourMode === 'free';
    var UNDO_MAX = 8;

    var W = 0, H = 0;
    var display, dctx, strokes, sctx, tcanvas, maskAlpha = null, img = null;
    var tool = 'brush', size = 12, painting = false, last = null, lineStart = null, undoStack = [], hasDrawn = false;
    var mapId = COLOR_MAPS[0].id, colorIdx = FREE ? 0 : -1, buffer = '', timerEnd = 0, timerRaf = null, calcExpr = '';
    var destroyed = false;

    function G(cls) { return el.querySelector('.' + cls); }
    function colors() { var m = COLOR_MAPS.filter(function (x) { return x.id === mapId; })[0] || COLOR_MAPS[0]; return m.colors; }
    function currentColor() { return colorIdx >= 0 ? colors()[colorIdx] : null; }

    el.innerHTML =
      '<div class="lgd">' +
        '<div class="lgd-toolrow">' +
          '<button type="button" class="lgd-tbtn sel" data-tool="brush">&#128396; Brush</button>' +
          '<button type="button" class="lgd-tbtn" data-tool="line">&#128207; Line</button>' +
          '<button type="button" class="lgd-tbtn" data-tool="fill">&#129699; Fill</button>' +
          '<button type="button" class="lgd-tbtn" data-tool="eraser">&#129533; Erase</button>' +
          '<button type="button" class="lgd-tbtn lgd-undo">&#8630; Undo</button>' +
          '<button type="button" class="lgd-tbtn danger lgd-clear">&#128465; Clear</button>' +
          '<label class="lgd-sizewrap">Size<input type="range" class="lgd-size" min="2" max="60" value="' + size + '"></label>' +
        '</div>' +
        '<div class="lgd-stage"><canvas class="lgd-canvas"></canvas><div class="lgd-msg" style="display:none"></div></div>' +
        '<div class="lgd-card lgd-mapcard"><div class="lgd-lbl">Colour map</div><select class="lgd-select lgd-colormap"></select></div>' +
        (FREE ? '' :
          '<div class="lgd-card">' +
            '<div class="lgd-lbl">Selected colour</div>' +
            '<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">' +
              '<div class="lgd-selsw" style="width:30px;height:30px;border-radius:6px;border:2px dashed #333e6b;flex-shrink:0"></div>' +
              '<span class="lgd-sellabel" style="font-size:.85rem;font-weight:700;color:#9aa3c4;font-family:monospace">No colour selected</span>' +
            '</div>' +
            '<div class="lgd-timerwrap" style="display:none">' +
              '<div style="display:flex;justify-content:space-between;font-size:.68rem;color:#9aa3c4;margin-bottom:3px"><span>Expires in</span><span class="lgd-timersecs" style="color:#fbbf24;font-weight:700"></span></div>' +
              '<div style="background:#1c2340;border-radius:99px;height:5px;overflow:hidden"><div class="lgd-timerbar" style="height:100%;width:100%;background:#fbbf24;border-radius:99px"></div></div>' +
            '</div>' +
            '<div class="lgd-expired" style="display:none;font-size:.72rem;color:#ff9a9a;font-weight:700;margin-top:4px">Type new binary to continue</div>' +
          '</div>' +
          '<div class="lgd-card">' +
            '<div class="lgd-lbl">Type binary (4 bits) - the colour number, in binary</div>' +
            '<div class="lgd-bits"></div>' +
            '<div class="lgd-bithint" style="font-size:.7rem;color:#6d76a0;text-align:center;margin-bottom:6px">Type 0 or 1 (keyboard works too)</div>' +
            '<div class="lgd-bitbtns">' +
              '<button type="button" class="lgd-bitbtn lgd-b0">0</button>' +
              '<button type="button" class="lgd-bitbtn lgd-b1">1</button>' +
              '<button type="button" class="lgd-bitbtn lgd-bbs" style="color:#9aa3c4;font-size:.9rem">&#9003;</button>' +
            '</div>' +
          '</div>') +
        '<div class="lgd-card"><div class="lgd-lbl">' + (FREE ? 'Colours' : 'Colour numbers') + '</div><div class="lgd-pal"></div></div>' +
        (FREE ? '' :
          '<details class="lgd-card"><summary style="cursor:pointer;font-size:.8rem;color:#9aa3c4;font-weight:700">Calculator</summary>' +
            '<div style="margin-top:8px"><div class="lgd-calc-disp">0</div><div class="lgd-calc-grid"></div></div>' +
          '</details>') +
        '<div class="lgd-need"></div>' +
      '</div>';

    display = G('lgd-canvas');
    dctx = display.getContext('2d');

    // ---- binary colour entry ----
    function renderBinary() {
      var c = G('lgd-bits'); if (!c) return;
      c.innerHTML = '';
      for (var i = 0; i < 4; i++) {
        var d = document.createElement('div');
        d.className = 'lgd-bit';
        d.style.border = '2px solid ' + (i < buffer.length ? '#4f7cff' : (i === buffer.length ? '#7a86ff' : '#333e6b'));
        d.style.background = i < buffer.length ? '#21295a' : '#141a30';
        if (i === buffer.length) d.style.boxShadow = '0 0 0 3px rgba(122,134,255,.35)';
        d.textContent = buffer[i] !== undefined ? buffer[i] : '';
        c.appendChild(d);
      }
      var hint = G('lgd-bithint');
      if (hint) {
        if (buffer.length > 0 && buffer.length < 4) { hint.textContent = buffer.length + ' of 4 bits...'; hint.style.color = '#7a86ff'; }
        else { hint.textContent = 'Type 0 or 1 (keyboard works too)'; hint.style.color = '#6d76a0'; }
      }
    }
    function pushBit(b) {
      buffer = (buffer + b).slice(0, 4);
      renderBinary();
      if (buffer.length === 4) { var idx = parseInt(buffer, 2); buffer = ''; renderBinary(); startColourTimer(idx); }
    }
    function keyHandler(e) {
      if (destroyed || !document.body.contains(el)) { document.removeEventListener('keydown', keyHandler); return; }
      var t = e.target, tag = t && t.tagName ? t.tagName.toLowerCase() : '';
      if (tag === 'input' || tag === 'textarea' || tag === 'select' || (t && t.isContentEditable)) return;
      if (e.key === '0' || e.key === '1') { e.preventDefault(); pushBit(e.key); }
      else if (e.key === 'Backspace') { e.preventDefault(); buffer = buffer.slice(0, -1); renderBinary(); }
    }
    function startColourTimer(idx) {
      stopColourTimer();
      colorIdx = idx; timerEnd = Date.now() + TIMER * 1000;
      G('lgd-timerwrap').style.display = '';
      G('lgd-expired').style.display = 'none';
      renderSelected(); renderPalette(); tick();
    }
    function stopColourTimer() { if (timerRaf) { cancelAnimationFrame(timerRaf); timerRaf = null; } }
    function tick() {
      if (destroyed) return;
      var rem = Math.max(0, timerEnd - Date.now());
      var s = G('lgd-timersecs'), b = G('lgd-timerbar');
      if (s) s.textContent = Math.ceil(rem / 1000) + 's';
      if (b) b.style.width = (rem / (TIMER * 1000) * 100) + '%';
      if (rem <= 0) {
        colorIdx = -1;
        G('lgd-timerwrap').style.display = 'none';
        G('lgd-expired').style.display = '';
        renderSelected(); renderPalette(); return;
      }
      timerRaf = requestAnimationFrame(tick);
    }
    function renderSelected() {
      if (FREE) return;
      var sw = G('lgd-selsw'), lb = G('lgd-sellabel');
      if (colorIdx < 0) {
        if (sw) { sw.style.background = 'transparent'; sw.style.border = '2px dashed #333e6b'; }
        if (lb) lb.textContent = 'No colour selected';
      } else {
        if (sw) { sw.style.background = colors()[colorIdx]; sw.style.border = '2px solid rgba(255,255,255,.25)'; }
        if (lb) lb.textContent = String(colorIdx);
      }
    }
    function renderPalette() {
      var c = G('lgd-pal'); if (!c) return;
      var cols = colors(); c.innerHTML = '';
      for (var i = 0; i < 16; i++) {
        var item = document.createElement('div');
        item.className = 'lgd-pal-item' + (FREE ? ' free' : '') + (i === colorIdx ? ' on' : '');
        var sw = document.createElement('div'); sw.className = 'lgd-pal-sw'; sw.style.background = cols[i];
        item.appendChild(sw);
        if (!FREE) { var n = document.createElement('span'); n.className = 'lgd-pal-n'; n.textContent = String(i); item.appendChild(n); }
        if (FREE) (function (idx) { item.addEventListener('click', function () { colorIdx = idx; if (tool === 'eraser') setTool('brush'); renderPalette(); }); })(i);
        c.appendChild(item);
      }
    }
    function populateMap() {
      var sel = G('lgd-colormap'); if (!sel) return;
      sel.innerHTML = '';
      COLOR_MAPS.forEach(function (m) {
        var o = document.createElement('option'); o.value = m.id; o.textContent = m.name;
        if (m.id === mapId) o.selected = true; sel.appendChild(o);
      });
      sel.onchange = function () { mapId = this.value; renderPalette(); renderSelected(); };
    }
    function initCalc() {
      var grid = G('lgd-calc-grid'); if (!grid) return;
      calcExpr = ''; calcDisplay('0'); grid.innerHTML = '';
      [['7','8','9','÷'],['4','5','6','×'],['1','2','3','−'],['C','0','=','+']].forEach(function (row) {
        row.forEach(function (label) {
          var btn = document.createElement('button'); btn.type = 'button'; btn.textContent = label;
          var isOp = ['÷','×','−','+'].indexOf(label) >= 0;
          btn.style.background = label === 'C' ? '#7f1d1d' : label === '=' ? '#1d4ed8' : isOp ? '#334155' : '#1c2340';
          btn.onclick = function () { calcPress(label); };
          grid.appendChild(btn);
        });
      });
    }
    // The original evaluated the expression with Function(); this parses
    // digits and + - x / by hand instead, so nothing student-typed is ever
    // executed as code.
    function calcEval(expr) {
      var toks = expr.replace(/÷/g, '/').replace(/×/g, '*').replace(/−/g, '-').match(/\d+\.?\d*|[+\-*/]/g) || [];
      var i = 0;
      function num() { var t = toks[i++]; if (t === '-') return -num(); var v = parseFloat(t); if (isNaN(v)) throw new Error('bad'); return v; }
      function term() { var v = num(); while (toks[i] === '*' || toks[i] === '/') { var op = toks[i++]; var r = num(); v = op === '*' ? v * r : v / r; } return v; }
      var v = term();
      while (toks[i] === '+' || toks[i] === '-') { var op2 = toks[i++]; var r2 = term(); v = op2 === '+' ? v + r2 : v - r2; }
      if (i < toks.length) throw new Error('bad');
      return v;
    }
    function calcPress(key) {
      if (key === 'C') { calcExpr = ''; calcDisplay('0'); return; }
      if (key === '=') {
        try { var r = Math.round(calcEval(calcExpr) * 1e10) / 1e10; calcExpr = String(r); calcDisplay(calcExpr); }
        catch (e) { calcDisplay('Error'); calcExpr = ''; }
        return;
      }
      calcExpr += key; calcDisplay(calcExpr);
    }
    function calcDisplay(v) { var e = G('lgd-calc-disp'); if (e) e.textContent = v || '0'; }
    function flashNeedColour() {
      var h = G('lgd-need'); if (!h) return;
      h.textContent = FREE ? 'Pick a colour first' : 'Type binary to pick a colour first';
      h.style.color = '#ff9a9a';
      setTimeout(function () { if (h) h.textContent = ''; }, 1800);
    }

    // ---- template + drawing surface ----
    function showMsg(html) { display.style.display = 'none'; var m = G('lgd-msg'); m.style.display = 'block'; m.innerHTML = html; }

    function setUp(templateCanvasBuilder, iw, ih) {
      var s = Math.min(1, MAXSIZE / Math.max(iw, ih));
      var dw = Math.max(1, Math.round(iw * s)), dh = Math.max(1, Math.round(ih * s)), dx = 0, dy = 0;
      if (OUTSIDE) {
        // Character mode: a roomier canvas with the locked design near the
        // bottom-centre, leaving space to draw a head, arms, legs, a hat...
        W = Math.round(dw * 1.7); H = Math.round(dh * 1.9);
        if (W > MAXSIZE * 1.4) {
          var k = (MAXSIZE * 1.4) / W;
          W = Math.round(W * k); H = Math.round(H * k); dw = Math.max(1, Math.round(dw * k)); dh = Math.max(1, Math.round(dh * k));
        }
        dx = Math.round((W - dw) / 2); dy = Math.round(dh * 0.78);
      } else { W = dw; H = dh; }
      var pixels = W * H;
      UNDO_MAX = pixels > 750000 ? 4 : pixels > 450000 ? 6 : 8;
      display.width = W; display.height = H;
      strokes = document.createElement('canvas'); strokes.width = W; strokes.height = H; sctx = strokes.getContext('2d');
      tcanvas = document.createElement('canvas'); tcanvas.width = W; tcanvas.height = H;
      templateCanvasBuilder(tcanvas.getContext('2d'), dx, dy, dw, dh);
      maskAlpha = new Uint8ClampedArray(W * H);
      var md = tcanvas.getContext('2d').getImageData(0, 0, W, H).data;
      for (var i = 0; i < W * H; i++) maskAlpha[i] = md[i * 4 + 3];
      render(); wirePointer();
      if (typeof options.onReady === 'function') options.onReady(api);
    }
    if (options.blank) {
      var bw = options.blank.w, bh = options.blank.h;
      setUp(function (tctx, dx, dy, dw, dh) { tctx.fillStyle = '#ffffff'; tctx.fillRect(dx, dy, dw, dh); }, bw, bh);
    } else {
      img = new Image();
      img.onload = function () {
        if (destroyed) return;
        setUp(function (tctx, dx, dy, dw, dh) { tctx.drawImage(img, dx, dy, dw, dh); }, img.naturalWidth, img.naturalHeight);
      };
      img.onerror = function () { showMsg('Could not load the design template. Tell your teacher.'); };
      img.src = options.templateUrl;
    }

    function inShirt(x, y) { return x >= 0 && y >= 0 && x < W && y < H && maskAlpha[y * W + x] >= 24; }
    function canDrawAt(x, y) {
      if (x < 0 || y < 0 || x >= W || y >= H) return false;
      var inside = inShirt(x, y);
      return OUTSIDE ? !inside : inside;
    }

    function render() {
      if (!W || destroyed) return;
      dctx.globalCompositeOperation = 'source-over';
      dctx.clearRect(0, 0, W, H);
      if (OUTSIDE) {
        dctx.drawImage(strokes, 0, 0);
        dctx.globalCompositeOperation = 'destination-out'; dctx.drawImage(tcanvas, 0, 0);
        dctx.globalCompositeOperation = 'source-over'; dctx.drawImage(tcanvas, 0, 0);
      } else {
        dctx.fillStyle = '#ffffff'; dctx.fillRect(0, 0, W, H);
        dctx.drawImage(strokes, 0, 0);
        dctx.globalCompositeOperation = 'destination-in'; dctx.drawImage(tcanvas, 0, 0);
        dctx.globalCompositeOperation = 'multiply'; dctx.drawImage(tcanvas, 0, 0);
        dctx.globalCompositeOperation = 'source-over';
      }
      if (lineStart) { dctx.fillStyle = 'rgba(79,124,255,.9)'; dctx.beginPath(); dctx.arc(lineStart.x, lineStart.y, Math.max(4, size / 2), 0, Math.PI * 2); dctx.fill(); }
    }

    function releaseCanvas(c) { if (c) { try { c.width = 0; c.height = 0; } catch (e) {} } }
    function pushUndo() {
      try {
        var snap = document.createElement('canvas'); snap.width = W; snap.height = H;
        snap.getContext('2d').drawImage(strokes, 0, 0);
        snap._hasDrawn = hasDrawn;
        undoStack.push(snap);
        while (undoStack.length > UNDO_MAX) releaseCanvas(undoStack.shift());
      } catch (e) {}
    }
    function undo() {
      if (!undoStack.length) return;
      var snap = undoStack.pop();
      sctx.clearRect(0, 0, W, H);
      try { sctx.drawImage(snap, 0, 0); } catch (e) {}
      hasDrawn = !!snap._hasDrawn;
      releaseCanvas(snap); render();
    }

    function drawSegment(a, b, erase) {
      sctx.save();
      sctx.lineCap = 'round'; sctx.lineJoin = 'round'; sctx.lineWidth = size;
      if (erase) { sctx.globalCompositeOperation = 'destination-out'; sctx.strokeStyle = 'rgba(0,0,0,1)'; }
      else { sctx.globalCompositeOperation = 'source-over'; sctx.strokeStyle = currentColor(); }
      sctx.beginPath(); sctx.moveTo(a.x, a.y); sctx.lineTo(b.x, b.y); sctx.stroke();
      if (OUTSIDE) { sctx.globalCompositeOperation = 'destination-out'; sctx.drawImage(tcanvas, 0, 0); }
      sctx.restore();
      if (!erase) hasDrawn = true;
    }

    function floodFill(px, py, hex) {
      var x = Math.round(px), y = Math.round(py);
      if (!canDrawAt(x, y)) return;
      var image = sctx.getImageData(0, 0, W, H), d = image.data, ti = (y * W + x) * 4;
      var tr = d[ti], tg = d[ti + 1], tb = d[ti + 2], ta = d[ti + 3], fc = hexToRgb(hex);
      if (ta === 255 && Math.abs(tr - fc.r) < 4 && Math.abs(tg - fc.g) < 4 && Math.abs(tb - fc.b) < 4) return;
      var TOL = 42;
      function match(i) { var a = d[i + 3]; if (ta < 24) return a < 24; return a >= 24 && Math.abs(d[i] - tr) <= TOL && Math.abs(d[i + 1] - tg) <= TOL && Math.abs(d[i + 2] - tb) <= TOL; }
      var total = W * H, stack = new Int32Array(total), visited = new Uint8Array(total), top = 0, start = y * W + x;
      stack[0] = start; visited[start] = 1;
      function enqueue(nx, ny) {
        if (nx < 0 || ny < 0 || nx >= W || ny >= H || !canDrawAt(nx, ny)) return;
        var idx = ny * W + nx;
        if (visited[idx] || !match(idx * 4)) return;
        visited[idx] = 1; stack[++top] = idx;
      }
      while (top >= 0) {
        var idx = stack[top--], cx = idx % W, cy = (idx / W) | 0, j = idx * 4;
        if (!match(j)) continue;
        d[j] = fc.r; d[j + 1] = fc.g; d[j + 2] = fc.b; d[j + 3] = 255;
        enqueue(cx - 1, cy); enqueue(cx + 1, cy); enqueue(cx, cy - 1); enqueue(cx, cy + 1);
      }
      sctx.putImageData(image, 0, 0);
      hasDrawn = true;
    }

    function pos(e) { var r = display.getBoundingClientRect(); return { x: (e.clientX - r.left) * (W / r.width), y: (e.clientY - r.top) * (H / r.height) }; }
    function needColour() { if (colorIdx < 0) { flashNeedColour(); return true; } return false; }
    function wirePointer() {
      display.addEventListener('pointerdown', function (e) {
        if (!W) return; e.preventDefault();
        var p = pos(e);
        if (tool === 'eraser') { pushUndo(); painting = true; try { display.setPointerCapture(e.pointerId); } catch (x) {} last = p; drawSegment(p, p, true); render(); return; }
        if (tool === 'fill') { if (needColour()) return; pushUndo(); floodFill(p.x, p.y, currentColor()); render(); return; }
        if (tool === 'line') {
          if (needColour()) return;
          if (!lineStart) { lineStart = p; render(); }
          else { pushUndo(); drawSegment(lineStart, p, false); lineStart = null; render(); }
          return;
        }
        if (needColour()) return;
        pushUndo(); painting = true; try { display.setPointerCapture(e.pointerId); } catch (x) {}
        last = p; drawSegment(p, p, false); render();
      });
      display.addEventListener('pointermove', function (e) {
        if (!painting) return; e.preventDefault();
        var p = pos(e); drawSegment(last, p, tool === 'eraser'); last = p; render();
      });
      function end() { painting = false; }
      display.addEventListener('pointerup', end);
      display.addEventListener('pointercancel', end);
      display.addEventListener('pointerleave', end);
    }

    function setTool(t) {
      tool = t; lineStart = null;
      Array.prototype.forEach.call(el.querySelectorAll('[data-tool]'), function (b) { b.classList.toggle('sel', b.getAttribute('data-tool') === t); });
      if (W) render();
    }
    Array.prototype.forEach.call(el.querySelectorAll('[data-tool]'), function (b) { b.addEventListener('click', function () { setTool(b.getAttribute('data-tool')); }); });
    G('lgd-size').addEventListener('input', function (e) { size = +e.target.value; });
    G('lgd-undo').addEventListener('click', undo);
    G('lgd-clear').addEventListener('click', function () { if (!W) return; pushUndo(); sctx.clearRect(0, 0, W, H); lineStart = null; hasDrawn = false; render(); });
    if (!FREE) {
      G('lgd-b0').onclick = function () { pushBit('0'); };
      G('lgd-b1').onclick = function () { pushBit('1'); };
      G('lgd-bbs').onclick = function () { buffer = buffer.slice(0, -1); renderBinary(); };
      document.addEventListener('keydown', keyHandler);
      renderBinary(); initCalc();
    }
    populateMap(); renderPalette(); renderSelected();

    var api = {
      element: el,
      toDataURL: function (type) { return W ? display.toDataURL(type || 'image/png') : null; },
      isEmpty: function () { return !W || !hasDrawn; },
      isReady: function () { return !!W; },
      clear: function () { if (W) { pushUndo(); sctx.clearRect(0, 0, W, H); hasDrawn = false; render(); } },
      destroy: function () {
        destroyed = true;
        stopColourTimer();
        document.removeEventListener('keydown', keyHandler);
        while (undoStack.length) releaseCanvas(undoStack.pop());
        painting = false; last = null; lineStart = null; maskAlpha = null;
        try { if (img) { img.onload = null; img.onerror = null; img.src = ''; } } catch (e2) {}
        releaseCanvas(strokes); releaseCanvas(tcanvas);
        el.innerHTML = '';
      }
    };
    return api;
  }

  window.LGDesigner = { create: create, COLOR_MAPS: COLOR_MAPS };
})();
