// ShipMap - draws the ship (an SVG tile map) and its crew, and turns clicks
// into tile / machine events. Shared by the student page and the teacher
// dashboard. All art is drawn here as SVG; nothing is loaded from files.
//
//   var view = ShipMap.create(svgElement, map, { moveMs: 140 });
//   view.setActors(actors, myId);       // characters (positions come from the server)
//   view.setFog(['O','D'] | null);      // zones currently visible (null = show everything)
//   view.follow(x, y) / view.setZoom(tilesAcross) / view.onTile(cb) / view.onMachine(cb)
(function () {
  'use strict';
  var NS = 'http://www.w3.org/2000/svg';
  var T = 40; // tile size in SVG units

  // Ten crew colours: body, dark (backpack/legs), light (helmet shine)
  var COLORS = [
    ['#e5484d', '#9c2b2f', '#ff8a8e'], ['#3e8ef7', '#255bab', '#8dbdff'], ['#30c48d', '#1b7f5b', '#7fe6bd'],
    ['#f5a524', '#b06f0a', '#ffd06b'], ['#a970ff', '#6a3fb0', '#cfa9ff'], ['#ec5fb0', '#a03577', '#ff9fd6'],
    ['#22c3d6', '#137a87', '#7feaf7'], ['#9ad13a', '#5f8a1b', '#cdf37a'], ['#f2f2f2', '#9a9fb0', '#ffffff'], ['#ff7a45', '#b04a1f', '#ffb08c']
  ];

  var ZONES = { // zone letter -> [x0, y0, x1, y1] in tiles (inclusive)
    O: [6, 6, 12, 12], N: [7, 0, 11, 4], E: [14, 7, 18, 11], S: [7, 14, 11, 18], W: [0, 7, 4, 11]
  };
  var ROOM_TINT = { n: '#2a1f2f', e: '#2a2a1c', s: '#1c2a33', w: '#1c2a2a' };
  var ROOM_LABEL = { N: 'REACTOR', E: 'WEAPONS', S: 'ELECTRICAL', W: 'NAVIGATION' };
  var DOORS = [[9, 5, 'v'], [9, 13, 'v'], [5, 9, 'h'], [13, 9, 'h']];

  function el(tag, attrs, parent) {
    var e = document.createElementNS(NS, tag);
    for (var k in attrs) if (attrs.hasOwnProperty(k)) e.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(e);
    return e;
  }
  function html(parent, markup) { parent.insertAdjacentHTML('beforeend', markup); }

  // ---------------- machine art (each drawn in a 40x40 tile, origin 0,0) ----------------
  var MACHINE_ART = {
    reactor:
      '<rect x="3" y="3" width="34" height="34" rx="6" fill="#2b2f45" stroke="#0e1120" stroke-width="2"/>' +
      '<circle cx="20" cy="20" r="14" fill="#171a2b"/>' +
      '<circle cx="20" cy="20" r="10" fill="url(#g-core)"/>' +
      '<circle cx="20" cy="20" r="14" fill="none" stroke="#ff8a4d" stroke-width="1.5" stroke-dasharray="4 3" opacity=".8"/>' +
      '<rect x="18" y="4" width="4" height="8" rx="1" fill="#8a91b8"/><rect x="18" y="28" width="4" height="8" rx="1" fill="#8a91b8"/>' +
      '<rect x="4" y="18" width="8" height="4" rx="1" fill="#8a91b8"/><rect x="28" y="18" width="8" height="4" rx="1" fill="#8a91b8"/>',
    weapons:
      '<rect x="3" y="5" width="34" height="30" rx="6" fill="#2b2f45" stroke="#0e1120" stroke-width="2"/>' +
      '<rect x="8" y="12" width="14" height="16" rx="4" fill="#4a5078"/>' +
      '<rect x="20" y="17" width="17" height="6" rx="2" fill="#8a91b8"/><rect x="33" y="15" width="4" height="10" rx="1" fill="#c9cdea"/>' +
      '<circle cx="15" cy="20" r="4" fill="#ff6b6b"/><circle cx="15" cy="20" r="1.6" fill="#fff"/>' +
      '<rect x="6" y="7" width="10" height="3" rx="1" fill="#ffb84d"/>',
    electrical:
      '<rect x="4" y="3" width="32" height="34" rx="5" fill="#2b2f45" stroke="#0e1120" stroke-width="2"/>' +
      '<rect x="8" y="7" width="24" height="12" rx="2" fill="#14172a"/>' +
      '<polygon points="22,8 14,16 19,16 17,22 27,13 21,13" fill="#ffd84d"/>' +
      '<rect x="9" y="24" width="4" height="9" rx="1" fill="#5be3a5"/><rect x="16" y="24" width="4" height="9" rx="1" fill="#5be3a5"/>' +
      '<rect x="23" y="24" width="4" height="9" rx="1" fill="#ff6b6b"/><rect x="30" y="24" width="3" height="9" rx="1" fill="#8a91b8"/>',
    navigation:
      '<rect x="3" y="4" width="34" height="32" rx="6" fill="#2b2f45" stroke="#0e1120" stroke-width="2"/>' +
      '<circle cx="20" cy="19" r="12" fill="#10233a" stroke="#4fd1ff" stroke-width="2"/>' +
      '<polygon points="20,9 23,19 20,29 17,19" fill="#4fd1ff"/><polygon points="20,9 23,19 17,19" fill="#ff6b6b"/>' +
      '<circle cx="20" cy="19" r="1.8" fill="#fff"/>' +
      '<rect x="7" y="32" width="7" height="2" rx="1" fill="#5be3a5"/><rect x="26" y="32" width="7" height="2" rx="1" fill="#ffb84d"/>'
  };

  // ---------------- the crew sprite (an original little astronaut) ----------------
  function crewMarkup(color, name, isMe) {
    var c = COLORS[color % COLORS.length];
    // A boxy little maintenance robot: square head with an eye strip and antenna,
    // a body panel with a chest light, stubby arms and feet.
    return '' +
      '<ellipse cx="20" cy="41" rx="11" ry="3" fill="rgba(0,0,0,.35)"/>' +
      '<g class="flip">' +
        '<g class="bob">' +
          '<rect class="leg leg-l" x="11" y="33" width="7" height="8" rx="2" fill="' + c[1] + '"/>' +
          '<rect class="leg leg-r" x="22" y="33" width="7" height="8" rx="2" fill="' + c[1] + '"/>' +
          '<rect x="5" y="22" width="6" height="12" rx="3" fill="' + c[1] + '"/>' +
          '<rect x="29" y="22" width="6" height="12" rx="3" fill="' + c[1] + '"/>' +
          '<rect x="10" y="21" width="20" height="14" rx="4" fill="' + c[0] + '" stroke="' + c[1] + '" stroke-width="1.5"/>' +
          '<circle cx="20" cy="28" r="3" fill="' + c[2] + '"/><circle cx="20" cy="28" r="1.3" fill="#fff"/>' +
          '<rect x="19" y="3" width="2" height="6" fill="' + c[1] + '"/><circle cx="20" cy="3" r="2.6" fill="' + c[2] + '"/>' +
          '<rect x="8" y="8" width="24" height="15" rx="5" fill="' + c[0] + '" stroke="' + c[1] + '" stroke-width="1.5"/>' +
          '<rect x="11" y="12" width="18" height="7" rx="3.5" fill="#10152b"/>' +
          '<circle cx="16" cy="15.5" r="2" fill="#8ff3ff"/><circle cx="24" cy="15.5" r="2" fill="#8ff3ff"/>' +
          '<rect x="10" y="9.5" width="9" height="2" rx="1" fill="' + c[2] + '" opacity=".6"/>' +
        '</g>' +
      '</g>' +
      '<text class="tag' + (isMe ? ' me' : '') + '" x="20" y="-2" text-anchor="middle">' + esc(name) + '</text>';
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  var CSS =
    '.ship-svg{touch-action:manipulation;user-select:none;-webkit-user-select:none}' +
    '.ship-actor{transition:transform var(--move-ms,140ms) linear}' +
    '.ship-actor .flip{transform-box:fill-box;transform-origin:center}' +
    '.ship-actor .tag{font:700 9px system-ui,sans-serif;fill:#eef1fb;paint-order:stroke;stroke:#0b0f1e;stroke-width:2.4px;stroke-linejoin:round}' +
    '.ship-actor .tag.me{fill:#ffd27a}' +
    '.ship-actor.walking .bob{animation:shipBob .28s ease-in-out infinite}' +
    '.ship-actor.walking .leg-l{animation:shipLegL .28s ease-in-out infinite}' +
    '.ship-actor.walking .leg-r{animation:shipLegR .28s ease-in-out infinite}' +
    '@keyframes shipBob{0%,100%{transform:translateY(0)}50%{transform:translateY(-1.6px)}}' +
    '@keyframes shipLegL{0%,100%{transform:translateY(0)}50%{transform:translateY(-2px)}}' +
    '@keyframes shipLegR{0%,100%{transform:translateY(-2px)}50%{transform:translateY(0)}}' +
    '.ship-machine{cursor:pointer}.ship-machine:hover .ship-hl{opacity:1}' +
    '.ship-hl{opacity:0;transition:opacity .15s}' +
    '.ship-fog{transition:opacity .25s;pointer-events:none}' +
    '.ship-pulse{animation:shipPulse 2.4s ease-in-out infinite}' +
    '@keyframes shipPulse{0%,100%{opacity:.55}50%{opacity:1}}' +
    '@media (prefers-reduced-motion:reduce){.ship-actor{transition:none}.ship-actor.walking .bob,.ship-actor.walking .leg-l,.ship-actor.walking .leg-r,.ship-pulse{animation:none}}';

  function injectCss() {
    if (document.getElementById('ship-css')) return;
    var s = document.createElement('style'); s.id = 'ship-css'; s.textContent = CSS; document.head.appendChild(s);
  }

  function create(svg, map, opts) {
    opts = opts || {};
    injectCss();
    var W = map.w, H = map.h, rows = map.rows;
    svg.setAttribute('class', (svg.getAttribute('class') || '') + ' ship-svg');
    svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
    svg.style.setProperty('--move-ms', (opts.moveMs || map.moveMs || 140) + 'ms');
    svg.innerHTML = '';

    var defs = el('defs', {}, svg);
    html(defs,
      '<radialGradient id="g-core"><stop offset="0" stop-color="#fff3c4"/><stop offset=".45" stop-color="#ffa94d"/><stop offset="1" stop-color="#d9480f"/></radialGradient>' +
      '<radialGradient id="g-table"><stop offset="0" stop-color="#3b4a7a"/><stop offset="1" stop-color="#1f2747"/></radialGradient>');

    var world = el('g', {}, svg);
    el('rect', { x: -T, y: -T, width: (W + 2) * T, height: (H + 2) * T, fill: '#070912' }, world); // space around the hull

    // floors and walls
    var floor = el('g', {}, world);
    var wallG = el('g', {}, world);
    for (var y = 0; y < H; y++) {
      for (var x = 0; x < W; x++) {
        var ch = rows[y].charAt(x);
        if (ch === '#') continue;
        var fill = '#262d4d';
        if (ch === '.') fill = ((x + y) % 2 ? '#2b3357' : '#262d4d');
        else if (ROOM_TINT[ch]) fill = ROOM_TINT[ch];
        else if (ch === 'D') fill = '#2f3a63';
        el('rect', { x: x * T, y: y * T, width: T, height: T, fill: fill }, floor);
        if (ROOM_TINT[ch]) el('rect', { x: x * T + 1, y: y * T + 1, width: T - 2, height: T - 2, fill: 'none', stroke: 'rgba(255,255,255,.04)' }, floor);
      }
    }
    // hull walls: draw every wall tile that touches a floor tile, with a lit edge
    for (var wy = 0; wy < H; wy++) {
      for (var wx = 0; wx < W; wx++) {
        if (rows[wy].charAt(wx) !== '#') continue;
        var touches = false;
        for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) {
          var nx = wx + dx, ny = wy + dy;
          if (nx >= 0 && ny >= 0 && nx < W && ny < H && rows[ny].charAt(nx) !== '#') touches = true;
        }
        if (!touches) continue;
        el('rect', { x: wx * T, y: wy * T, width: T, height: T, fill: '#3a4373' }, wallG);
        el('rect', { x: wx * T, y: wy * T, width: T, height: 5, fill: '#5561a0' }, wallG);
        el('rect', { x: wx * T, y: wy * T + T - 3, width: T, height: 3, fill: '#242a4b' }, wallG);
      }
    }
    // room names, painted faintly on the floor
    Object.keys(ROOM_LABEL).forEach(function (z) {
      var r = ZONES[z];
      var t = el('text', { x: (r[0] + r[2] + 1) / 2 * T, y: (r[1] + r[3] + 1) / 2 * T + 6, 'text-anchor': 'middle', fill: 'rgba(255,255,255,.10)', 'font-size': 17, 'font-weight': 800, 'letter-spacing': 3, 'font-family': 'system-ui,sans-serif' }, world);
      t.textContent = ROOM_LABEL[z];
    });
    // office rug and table
    var ro = ZONES.O;
    el('rect', { x: (ro[0] + 0.3) * T, y: (ro[1] + 0.3) * T, width: (ro[2] - ro[0] + 0.4) * T, height: (ro[3] - ro[1] + 0.4) * T, rx: 14, fill: 'none', stroke: 'rgba(120,140,255,.18)', 'stroke-width': 2, 'stroke-dasharray': '6 6' }, world);
    var tc = el('g', { transform: 'translate(' + 9.5 * T + ',' + 9.5 * T + ')' }, world);
    el('circle', { r: 58, fill: '#141935' }, tc);
    el('circle', { r: 54, fill: 'url(#g-table)', stroke: '#5561a0', 'stroke-width': 3 }, tc);
    el('circle', { r: 30, fill: 'none', stroke: '#4fd1ff', 'stroke-width': 1.5, 'stroke-dasharray': '3 4', opacity: '.7' }, tc);
    el('circle', { r: 5, fill: '#4fd1ff', class: 'ship-pulse' }, tc);
    var ot = el('text', { y: 42, 'text-anchor': 'middle', fill: 'rgba(255,255,255,.35)', 'font-size': 8, 'font-weight': 800, 'letter-spacing': 2, 'font-family': 'system-ui,sans-serif' }, tc);
    ot.textContent = 'OFFICE';

    // doors
    DOORS.forEach(function (d) {
      var gx = d[0] * T, gy = d[1] * T, g = el('g', {}, world);
      if (d[2] === 'v') { el('rect', { x: gx, y: gy, width: 6, height: T, fill: '#c98a1c' }, g); el('rect', { x: gx + T - 6, y: gy, width: 6, height: T, fill: '#c98a1c' }, g); el('rect', { x: gx + 6, y: gy + T / 2 - 1.5, width: T - 12, height: 3, fill: '#ffd27a', class: 'ship-pulse' }, g); }
      else { el('rect', { x: gx, y: gy, width: T, height: 6, fill: '#c98a1c' }, g); el('rect', { x: gx, y: gy + T - 6, width: T, height: 6, fill: '#c98a1c' }, g); el('rect', { x: gx + T / 2 - 1.5, y: gy + 6, width: 3, height: T - 12, fill: '#ffd27a', class: 'ship-pulse' }, g); }
    });

    // machines (clickable)
    var machineG = el('g', {}, world);
    (map.machines || []).forEach(function (m) {
      var g = el('g', { class: 'ship-machine', transform: 'translate(' + m.x * T + ',' + m.y * T + ')', 'data-machine': m.id }, machineG);
      html(g, MACHINE_ART[m.id] || '<rect width="40" height="40" fill="#666"/>');
      el('rect', { class: 'ship-hl', x: -2, y: -2, width: T + 4, height: T + 4, rx: 8, fill: 'none', stroke: '#ffd27a', 'stroke-width': 2.5 }, g);
      el('rect', { x: 0, y: 0, width: T, height: T, fill: 'transparent' }, g);
      g.addEventListener('click', function (e) { e.stopPropagation(); if (machineCb) machineCb(m); });
    });

    // fog overlay, one shape per zone
    var fogG = el('g', {}, world);
    var fogEls = {};
    Object.keys(ZONES).forEach(function (z) {
      var r = ZONES[z];
      fogEls[z] = el('rect', { class: 'ship-fog', x: r[0] * T, y: r[1] * T, width: (r[2] - r[0] + 1) * T, height: (r[3] - r[1] + 1) * T, fill: '#05070f', opacity: 0 }, fogG);
    });
    var doorFog = DOORS.map(function (d) { return el('rect', { class: 'ship-fog', x: d[0] * T, y: d[1] * T, width: T, height: T, fill: '#05070f', opacity: 0 }, fogG); });

    var actorG = el('g', {}, world);
    var actors = {};
    var tileCb = null, machineCb = null;

    // ---- camera: a viewBox that eases toward a target ----
    var cam = { cx: W / 2, cy: H / 2, tiles: W }, target = { cx: W / 2, cy: H / 2, tiles: W }, raf = 0;
    function applyCam() {
      var box = svg.getBoundingClientRect();
      var aspect = box.width > 0 && box.height > 0 ? box.width / box.height : 1;
      // 'tiles' is how many tiles fit across the SHORTER side, so the whole ship
      // always fits when tiles >= the map size, on any screen shape.
      var vw, vh;
      if (aspect >= 1) { vh = cam.tiles * T; vw = vh * aspect; } else { vw = cam.tiles * T; vh = vw / aspect; }
      svg.setAttribute('viewBox', (cam.cx * T - vw / 2) + ' ' + (cam.cy * T - vh / 2) + ' ' + vw + ' ' + vh);
    }
    function loop() {
      var k = 0.18;
      cam.cx += (target.cx - cam.cx) * k; cam.cy += (target.cy - cam.cy) * k; cam.tiles += (target.tiles - cam.tiles) * k;
      applyCam();
      raf = requestAnimationFrame(loop);
    }
    applyCam(); raf = requestAnimationFrame(loop);

    svg.addEventListener('click', function (e) {
      if (!tileCb) return;
      var pt = svg.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY;
      var p = pt.matrixTransform(svg.getScreenCTM().inverse());
      var tx = Math.floor(p.x / T), ty = Math.floor(p.y / T);
      if (tx < 0 || ty < 0 || tx >= W || ty >= H) return;
      tileCb(tx, ty, rows[ty].charAt(tx));
    });

    function ensureActor(a, isMe) {
      var g = actors[a.id];
      if (g && g._color === a.color && g._name === a.name) return g;
      if (g) g.remove();
      g = el('g', { class: 'ship-actor' }, actorG);
      html(g, crewMarkup(a.color, a.name, isMe));
      g._color = a.color; g._name = a.name;
      actors[a.id] = g;
      return g;
    }

    return {
      setActors: function (list, meId) {
        var seen = {};
        list.forEach(function (a) {
          seen[a.id] = true;
          var g = ensureActor(a, a.id === meId);
          g.style.transform = 'translate(' + a.x * T + 'px,' + (a.y * T - 6) + 'px)';
          g.classList.toggle('walking', !!a.walking);
          var flip = g.querySelector('.flip');
          if (flip) flip.style.transform = 'scaleX(' + (a.face < 0 ? -1 : 1) + ')';
          g.style.opacity = a.ghost ? 0.5 : 1;
          if (a.id === meId) actorG.appendChild(g); // keep yourself on top
        });
        Object.keys(actors).forEach(function (id) { if (!seen[id]) { actors[id].remove(); delete actors[id]; } });
      },
      setFog: function (visible) {
        Object.keys(fogEls).forEach(function (z) { fogEls[z].setAttribute('opacity', (!visible || visible.indexOf(z) >= 0) ? 0 : 0.62); });
        doorFog.forEach(function (d) { d.setAttribute('opacity', (!visible || visible.indexOf('D') >= 0) ? 0 : 0.62); });
      },
      follow: function (x, y) { target.cx = x + 0.5; target.cy = y + 0.5; },
      setZoom: function (tiles) { target.tiles = tiles; if (tiles >= W) { target.cx = W / 2; target.cy = H / 2; } },
      onTile: function (cb) { tileCb = cb; },
      onMachine: function (cb) { machineCb = cb; },
      destroy: function () { cancelAnimationFrame(raf); svg.innerHTML = ''; }
    };
  }

  window.ShipMap = { create: create, COLORS: COLORS, TILE: T };
})();
