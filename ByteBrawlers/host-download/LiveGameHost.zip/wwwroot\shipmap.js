// ShipMap - draws the ship (an SVG tile map) and its crew, and turns clicks
// into tile / machine / vent events. Shared by the student page and the
// teacher dashboard. All art is drawn here as SVG; nothing is loaded from files.
//
//   var view = ShipMap.create(svgElement, map, { moveMs: 130 });
//   view.setActors(actors, myId);       // characters (positions come from the server)
//   view.setFog(['O','n'] | null);      // zones currently visible (null = show everything)
//   view.follow(x, y);                  // camera target, in tiles
//   view.setFit(16, 10);                // how many tiles must fit on screen (a room is ~15x9)
//   view.showFx([{x,y}]);               // vent puffs
//   view.onTile(cb) / view.onMachine(cb)
(function () {
  'use strict';
  var NS = 'http://www.w3.org/2000/svg';
  var T = 40; // tile size in SVG units

  // Ten crew colours: body, dark (limbs), light (highlights)
  var COLORS = [
    ['#e5484d', '#9c2b2f', '#ff8a8e'], ['#3e8ef7', '#255bab', '#8dbdff'], ['#30c48d', '#1b7f5b', '#7fe6bd'],
    ['#f5a524', '#b06f0a', '#ffd06b'], ['#a970ff', '#6a3fb0', '#cfa9ff'], ['#ec5fb0', '#a03577', '#ff9fd6'],
    ['#22c3d6', '#137a87', '#7feaf7'], ['#9ad13a', '#5f8a1b', '#cdf37a'], ['#f2f2f2', '#9a9fb0', '#ffffff'], ['#ff7a45', '#b04a1f', '#ffb08c']
  ];

  var FLOOR = { // per zone: [pattern id, label]
    O: ['p-office', 'OFFICE'], N: ['p-n', 'REACTOR'], E: ['p-e', 'WEAPONS'], S: ['p-s', 'ELECTRICAL'], W: ['p-w', 'NAVIGATION'],
    A: ['p-a', 'STORAGE'], B: ['p-b', 'O2'], C: ['p-c', 'SHIELDS'], D: ['p-d', 'MEDBAY'],
    n: ['p-cor', ''], e: ['p-cor', ''], s: ['p-cor', ''], w: ['p-cor', ''],
    a: ['p-cor', ''], b: ['p-cor', ''], c: ['p-cor', ''], d: ['p-cor', ''], f: ['p-cor', ''], g: ['p-cor', ''], h: ['p-cor', ''], i: ['p-cor', '']
  };

  function el(tag, attrs, parent) {
    var e = document.createElementNS(NS, tag);
    for (var k in attrs) if (attrs.hasOwnProperty(k)) e.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(e);
    return e;
  }
  function html(parent, markup) { parent.insertAdjacentHTML('beforeend', markup); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  // ---------------- machine art (each drawn in a 40x40 tile, origin 0,0) ----------------
  var MACHINE_ART = {
    reactor:
      '<rect x="3" y="3" width="34" height="34" rx="6" fill="#2b2f45" stroke="#0e1120" stroke-width="2"/>' +
      '<circle cx="20" cy="20" r="14" fill="#171a2b"/>' +
      '<circle cx="20" cy="20" r="10" fill="url(#g-core)"/>' +
      '<circle cx="20" cy="20" r="14" fill="none" stroke="#ff8a4d" stroke-width="1.5" stroke-dasharray="4 3" opacity=".8"/>' +
      '<rect x="18" y="4" width="4" height="8" rx="1" fill="#8a91b8"/><rect x="18" y="28" width="4" height="8" rx="1" fill="#8a91b8"/>' +
      '<rect x="4" y="18" width="8" height="4" rx="1" fill="#8a91b8"/><rect x="28" y="18" width="8" height="4" rx="1" fill="#8a91b8"/>',
    weapons:
      '<rect x="3" y="5" width="34" height="30" rx="6" fill="#2b2f45" stroke="#0e1120" stroke-width="2"/>' +
      '<rect x="8" y="12" width="14" height="16" rx="4" fill="#4a5078"/>' +
      '<rect x="20" y="17" width="17" height="6" rx="2" fill="#8a91b8"/><rect x="33" y="15" width="4" height="10" rx="1" fill="#c9cdea"/>' +
      '<circle cx="15" cy="20" r="4" fill="#ff6b6b"/><circle cx="15" cy="20" r="1.6" fill="#fff"/>' +
      '<rect x="6" y="7" width="10" height="3" rx="1" fill="#ffb84d"/>',
    electrical:
      '<rect x="4" y="3" width="32" height="34" rx="5" fill="#2b2f45" stroke="#0e1120" stroke-width="2"/>' +
      '<rect x="8" y="7" width="24" height="12" rx="2" fill="#14172a"/>' +
      '<polygon points="22,8 14,16 19,16 17,22 27,13 21,13" fill="#ffd84d"/>' +
      '<rect x="9" y="24" width="4" height="9" rx="1" fill="#5be3a5"/><rect x="16" y="24" width="4" height="9" rx="1" fill="#5be3a5"/>' +
      '<rect x="23" y="24" width="4" height="9" rx="1" fill="#ff6b6b"/><rect x="30" y="24" width="3" height="9" rx="1" fill="#8a91b8"/>',
    navigation:
      '<rect x="3" y="4" width="34" height="32" rx="6" fill="#2b2f45" stroke="#0e1120" stroke-width="2"/>' +
      '<circle cx="20" cy="19" r="12" fill="#10233a" stroke="#4fd1ff" stroke-width="2"/>' +
      '<polygon points="20,9 23,19 20,29 17,19" fill="#4fd1ff"/><polygon points="20,9 23,19 17,19" fill="#ff6b6b"/>' +
      '<circle cx="20" cy="19" r="1.8" fill="#fff"/>' +
      '<rect x="7" y="32" width="7" height="2" rx="1" fill="#5be3a5"/><rect x="26" y="32" width="7" height="2" rx="1" fill="#ffb84d"/>'
  };
  MACHINE_ART.storage =
    '<rect x="3" y="5" width="34" height="30" rx="4" fill="#2b2f45" stroke="#0e1120" stroke-width="2"/>' +
    '<rect x="7" y="9" width="12" height="10" fill="#b0803a" stroke="#0e1120"/><rect x="21" y="9" width="12" height="10" fill="#c99a4d" stroke="#0e1120"/>' +
    '<rect x="7" y="21" width="26" height="10" fill="#9a6d2e" stroke="#0e1120"/><path d="M7 26h26M20 21v10" stroke="#0e1120"/>';
  MACHINE_ART.o2 =
    '<rect x="3" y="3" width="34" height="34" rx="6" fill="#2b2f45" stroke="#0e1120" stroke-width="2"/>' +
    '<circle cx="20" cy="20" r="12" fill="#10283a" stroke="#5be3a5" stroke-width="2"/>' +
    '<text x="20" y="25" text-anchor="middle" font-size="13" font-weight="800" fill="#5be3a5" font-family="Arial,sans-serif">O2</text>';
  MACHINE_ART.shields =
    '<rect x="3" y="3" width="34" height="34" rx="6" fill="#2b2f45" stroke="#0e1120" stroke-width="2"/>' +
    '<path d="M20 6 L33 11 V21 C33 29 27 33 20 36 C13 33 7 29 7 21 V11 Z" fill="#1a2f55" stroke="#4fd1ff" stroke-width="2"/>' +
    '<path d="M20 11 L28 14 V21 C28 26 24 29 20 31 Z" fill="#4fd1ff" opacity=".6"/>';
  MACHINE_ART.medbay =
    '<rect x="3" y="4" width="34" height="32" rx="6" fill="#2b2f45" stroke="#0e1120" stroke-width="2"/>' +
    '<rect x="8" y="9" width="24" height="22" rx="3" fill="#14172a"/>' +
    '<rect x="17" y="12" width="6" height="16" fill="#ff6b6b"/><rect x="12" y="17" width="16" height="6" fill="#ff6b6b"/>';
  var VENT_ART =
    '<rect x="2" y="6" width="36" height="28" rx="4" fill="#232840" stroke="#0a0d1a" stroke-width="2"/>' +
    '<rect x="6" y="10" width="28" height="20" rx="2" fill="#0a0d1a"/>' +
    '<rect x="8" y="12" width="24" height="3" fill="#6b7398"/><rect x="8" y="17" width="24" height="3" fill="#6b7398"/>' +
    '<rect x="8" y="22" width="24" height="3" fill="#6b7398"/><rect x="8" y="27" width="24" height="2" fill="#6b7398"/>' +
    '<circle cx="5" cy="9" r="1.5" fill="#8a91b8"/><circle cx="35" cy="9" r="1.5" fill="#8a91b8"/><circle cx="5" cy="31" r="1.5" fill="#8a91b8"/><circle cx="35" cy="31" r="1.5" fill="#8a91b8"/>';

  // ---------------- the crew sprite: an original boxy maintenance robot ----------------
  function crewMarkup(color, name, isMe, role) {
    var c = COLORS[color % COLORS.length];
    var traitor = role === 'traitor';
    var eye = traitor ? '#ff5b5b' : '#8ff3ff';
    var ant = traitor ? '#ff3b3b' : c[2];
    return '' +
      '<ellipse cx="20" cy="41" rx="11" ry="3" fill="rgba(0,0,0,.35)"/>' +
      '<g class="flip">' +
        '<g class="bob">' +
          '<rect class="leg leg-l" x="11" y="33" width="7" height="8" rx="2" fill="' + c[1] + '"/>' +
          '<rect class="leg leg-r" x="22" y="33" width="7" height="8" rx="2" fill="' + c[1] + '"/>' +
          '<rect x="5" y="22" width="6" height="12" rx="3" fill="' + c[1] + '"/>' +
          '<rect x="29" y="22" width="6" height="12" rx="3" fill="' + c[1] + '"/>' +
          '<rect x="10" y="21" width="20" height="14" rx="4" fill="' + c[0] + '" stroke="' + c[1] + '" stroke-width="1.5"/>' +
          '<circle cx="20" cy="28" r="3" fill="' + (traitor ? '#ff3b3b' : c[2]) + '"/><circle cx="20" cy="28" r="1.3" fill="#fff"/>' +
          '<rect x="19" y="3" width="2" height="6" fill="' + c[1] + '"/><circle cx="20" cy="3" r="2.6" fill="' + ant + '"/>' +
          '<rect x="8" y="8" width="24" height="15" rx="5" fill="' + c[0] + '" stroke="' + c[1] + '" stroke-width="1.5"/>' +
          '<rect x="11" y="12" width="18" height="7" rx="3.5" fill="#10152b"/>' +
          (traitor
            ? '<polygon points="12.5,13 18.5,16 12.5,18" fill="' + eye + '"/><polygon points="27.5,13 21.5,16 27.5,18" fill="' + eye + '"/>'
            : '<circle cx="16" cy="15.5" r="2" fill="' + eye + '"/><circle cx="24" cy="15.5" r="2" fill="' + eye + '"/>') +
          '<rect x="10" y="9.5" width="9" height="2" rx="1" fill="' + c[2] + '" opacity=".6"/>' +
        '</g>' +
      '</g>' +
      '<text class="tag' + (isMe ? ' me' : '') + (traitor ? ' traitor' : '') + '" x="20" y="-2" text-anchor="middle">' + esc(name) + '</text>';
  }

  var CSS =
    '.ship-svg{touch-action:manipulation;user-select:none;-webkit-user-select:none}' +
    '.ship-actor .flip{transform-box:fill-box;transform-origin:center}' +
    '.ship-actor .tag{font:700 9px system-ui,sans-serif;fill:#eef1fb;paint-order:stroke;stroke:#0b0f1e;stroke-width:2.4px;stroke-linejoin:round}' +
    '.ship-actor .tag.me{fill:#ffd27a}.ship-actor .tag.traitor{fill:#ff7b7b}' +
    '.ship-actor.walking .bob{animation:shipBob .28s ease-in-out infinite}' +
    '.ship-actor.walking .leg-l{animation:shipLegL .28s ease-in-out infinite}' +
    '.ship-actor.walking .leg-r{animation:shipLegR .28s ease-in-out infinite}' +
    '@keyframes shipBob{0%,100%{transform:translateY(0)}50%{transform:translateY(-1.6px)}}' +
    '@keyframes shipLegL{0%,100%{transform:translateY(0)}50%{transform:translateY(-2px)}}' +
    '@keyframes shipLegR{0%,100%{transform:translateY(-2px)}50%{transform:translateY(0)}}' +
    '.ship-machine,.ship-vent{cursor:pointer}.ship-machine:hover .ship-hl,.ship-vent:hover .ship-hl{opacity:1}' +
    '.ship-hl{opacity:0;transition:opacity .15s}' +
    '.ship-fog{transition:opacity .3s;pointer-events:none}' +
    '.ship-pulse{animation:shipPulse 2.4s ease-in-out infinite}' +
    '@keyframes shipPulse{0%,100%{opacity:.55}50%{opacity:1}}' +
    '.ship-puff{animation:shipPuff .9s ease-out forwards;transform-box:fill-box;transform-origin:center}' +
    '@keyframes shipPuff{0%{opacity:.9;transform:scale(.3)}100%{opacity:0;transform:scale(2.4)}}' +
    '.ship-ring{animation:shipRing .9s ease-in-out infinite}' +
    '@keyframes shipRing{0%,100%{opacity:.35}50%{opacity:1}}' +
    '@media (prefers-reduced-motion:reduce){.ship-ring{animation:none;opacity:1}.ship-actor.walking .bob,.ship-actor.walking .leg-l,.ship-actor.walking .leg-r,.ship-pulse,.ship-puff{animation:none}}';

  function injectCss() {
    if (document.getElementById('ship-css')) return;
    var s = document.createElement('style'); s.id = 'ship-css'; s.textContent = CSS; document.head.appendChild(s);
  }

  function pattern(id, a, b) {
    return '<pattern id="' + id + '" width="' + 2 * T + '" height="' + 2 * T + '" patternUnits="userSpaceOnUse">' +
      '<rect width="' + 2 * T + '" height="' + 2 * T + '" fill="' + a + '"/>' +
      '<rect x="' + T + '" width="' + T + '" height="' + T + '" fill="' + b + '"/><rect y="' + T + '" width="' + T + '" height="' + T + '" fill="' + b + '"/></pattern>';
  }

  function create(svg, map, opts) {
    opts = opts || {};
    injectCss();
    var W = map.w, H = map.h, rows = map.rows;
    svg.setAttribute('class', (svg.getAttribute('class') || '') + ' ship-svg');
    svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
    svg.style.setProperty('--move-ms', (opts.moveMs || map.moveMs || 130) + 'ms');
    svg.innerHTML = '';

    var defs = el('defs', {}, svg);
    html(defs,
      '<radialGradient id="g-core"><stop offset="0" stop-color="#fff3c4"/><stop offset=".45" stop-color="#ffa94d"/><stop offset="1" stop-color="#d9480f"/></radialGradient>' +
      '<radialGradient id="g-table"><stop offset="0" stop-color="#3b4a7a"/><stop offset="1" stop-color="#1f2747"/></radialGradient>' +
      '<radialGradient id="g-puff"><stop offset="0" stop-color="#e8ecff" stop-opacity=".95"/><stop offset="1" stop-color="#8a91b8" stop-opacity="0"/></radialGradient>' +
      pattern('p-office', '#2b3357', '#262d4d') + pattern('p-n', '#33232f', '#2c1f2a') + pattern('p-e', '#33301f', '#2c2a1a') +
      '<pattern id="p-hazard" width="24" height="24" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="24" height="24" fill="#3a1014"/><rect width="12" height="24" fill="#ff3b3b"/></pattern>' +
      pattern('p-s', '#1f3240', '#1a2b38') + pattern('p-w', '#1f3333', '#1a2b2b') + pattern('p-cor', '#2a3050', '#252b47') + pattern('p-a', '#33291f', '#2c231a') + pattern('p-b', '#1f3328', '#1a2c22') + pattern('p-c', '#2a1f40', '#231a37') + pattern('p-d', '#331f2a', '#2c1a24'));

    var world = el('g', {}, svg);
    el('rect', { x: -6 * T, y: -6 * T, width: (W + 12) * T, height: (H + 12) * T, fill: '#070912' }, world);
    // a few stars in the void around the hull (deterministic, so every screen matches)
    var seed = 7;
    function rnd() { seed = (seed * 16807) % 2147483647; return seed / 2147483647; }
    for (var i = 0; i < 160; i++) el('circle', { cx: (rnd() * (W + 12) - 6) * T, cy: (rnd() * (H + 12) - 6) * T, r: 0.6 + rnd() * 1.4, fill: '#8a91b8', opacity: 0.25 + rnd() * 0.5 }, world);

    var regions = map.regions || [];
    // hull walls: each region grown by one tile, drawn before any floor so openings stay open
    regions.forEach(function (r) {
      el('rect', { x: (r.x0 - 1) * T, y: (r.y0 - 1) * T, width: (r.x1 - r.x0 + 3) * T, height: (r.y1 - r.y0 + 3) * T, fill: '#39426f', rx: 6 }, world);
    });
    regions.forEach(function (r) {
      el('rect', { x: (r.x0 - 1) * T + 3, y: (r.y0 - 1) * T + 3, width: (r.x1 - r.x0 + 3) * T - 6, height: (r.y1 - r.y0 + 3) * T - 6, fill: '#2c3460', rx: 4 }, world);
    });
    regions.forEach(function (r) {
      var f = FLOOR[r.zone] || FLOOR.O;
      el('rect', { x: r.x0 * T, y: r.y0 * T, width: (r.x1 - r.x0 + 1) * T, height: (r.y1 - r.y0 + 1) * T, fill: 'url(#' + f[0] + ')' }, world);
    });
    // room names, painted faintly on the floor
    regions.forEach(function (r) {
      var f = FLOOR[r.zone];
      if (!f || !f[1]) return;
      var t = el('text', { x: (r.x0 + r.x1 + 1) / 2 * T, y: (r.y0 + r.y1 + 1) / 2 * T + 14, 'text-anchor': 'middle', fill: 'rgba(255,255,255,.10)', 'font-size': 44, 'font-weight': 800, 'letter-spacing': 8, 'font-family': 'system-ui,sans-serif' }, world);
      t.textContent = f[1];
    });
    // bulkhead frames where each corridor meets a room, and a guide stripe down its middle
    regions.filter(function (r) { return r.kind === 'corridor'; }).forEach(function (r) {
      var vertical = (r.y1 - r.y0) > (r.x1 - r.x0);
      var lines = vertical
        ? [[r.x0 * T, r.y0 * T - 3, (r.x1 - r.x0 + 1) * T, 6], [r.x0 * T, (r.y1 + 1) * T - 3, (r.x1 - r.x0 + 1) * T, 6]]
        : [[r.x0 * T - 3, r.y0 * T, 6, (r.y1 - r.y0 + 1) * T], [(r.x1 + 1) * T - 3, r.y0 * T, 6, (r.y1 - r.y0 + 1) * T]];
      lines.forEach(function (l) {
        el('rect', { x: l[0], y: l[1], width: l[2], height: l[3], fill: '#c98a1c' }, world);
        el('rect', { x: l[0], y: l[1], width: l[2], height: l[3], fill: '#ffd27a', class: 'ship-pulse', opacity: 0.4 }, world);
      });
      var mid = vertical
        ? { x: (r.x0 + 1) * T - 1.5, y: r.y0 * T + 12, width: 3, height: (r.y1 - r.y0 + 1) * T - 24 }
        : { x: r.x0 * T + 12, y: (r.y0 + 1) * T - 1.5, width: (r.x1 - r.x0 + 1) * T - 24, height: 3 };
      el('rect', { x: mid.x, y: mid.y, width: mid.width, height: mid.height, fill: 'rgba(255,210,122,.18)' }, world);
    });

    // solid props
    (map.crates || []).forEach(function (c) {
      var g = el('g', { transform: 'translate(' + c.x * T + ',' + c.y * T + ')' }, world);
      el('rect', { x: 2, y: 2, width: c.w * T - 4, height: c.h * T - 4, rx: 6, fill: '#4a4f73', stroke: '#1a1e36', 'stroke-width': 2 }, g);
      el('rect', { x: 8, y: 8, width: c.w * T - 16, height: c.h * T - 16, rx: 4, fill: 'none', stroke: '#6b7398', 'stroke-width': 2 }, g);
      el('path', { d: 'M8 8 L' + (c.w * T - 8) + ' ' + (c.h * T - 8) + ' M' + (c.w * T - 8) + ' 8 L8 ' + (c.h * T - 8), stroke: '#6b7398', 'stroke-width': 2 }, g);
    });
    if (map.table) {
      var tb = map.table, tcx = (tb.x + tb.w / 2) * T, tcy = (tb.y + tb.h / 2) * T;
      var tc = el('g', { transform: 'translate(' + tcx + ',' + tcy + ')' }, world);
      el('circle', { r: tb.w * T / 2 + 6, fill: '#141935' }, tc);
      el('circle', { r: tb.w * T / 2 + 2, fill: 'url(#g-table)', stroke: '#5561a0', 'stroke-width': 3 }, tc);
      el('circle', { r: tb.w * T / 2 - 26, fill: 'none', stroke: '#4fd1ff', 'stroke-width': 1.5, 'stroke-dasharray': '3 4', opacity: '.7' }, tc);
      el('circle', { r: 7, fill: '#4fd1ff', class: 'ship-pulse' }, tc);
      var ot = el('text', { y: tb.w * T / 2 - 12, 'text-anchor': 'middle', fill: 'rgba(255,255,255,.4)', 'font-size': 11, 'font-weight': 800, 'letter-spacing': 3, 'font-family': 'system-ui,sans-serif' }, tc);
      ot.textContent = 'MEETING TABLE';
    }

    var tileCb = null, machineCb = null;
    var machineGroups = [];

    // machines and vents (clickable objects)
    var objG = el('g', {}, world);
    (map.machines || []).forEach(function (m) {
      var g = el('g', { class: 'ship-machine', transform: 'translate(' + m.x * T + ',' + m.y * T + ')' }, objG);
      html(g, MACHINE_ART[m.id] || '<rect width="40" height="40" fill="#666"/>');
      el('rect', { class: 'ship-hl', x: -2, y: -2, width: T + 4, height: T + 4, rx: 8, fill: 'none', stroke: '#ffd27a', 'stroke-width': 2.5 }, g);
      g._ring = el('rect', { class: 'ship-ring', x: -7, y: -7, width: T + 14, height: T + 14, rx: 12, fill: 'rgba(255,59,59,.12)', stroke: '#ff3b3b', 'stroke-width': 3, display: 'none' }, g);
      g._id = m.id; machineGroups.push(g);
      el('rect', { x: 0, y: 0, width: T, height: T, fill: 'transparent' }, g);
      g.addEventListener('click', function (e) { e.stopPropagation(); if (machineCb) machineCb(m); });
    });
    (map.vents || []).forEach(function (v) {
      var g = el('g', { class: 'ship-vent', transform: 'translate(' + v.x * T + ',' + v.y * T + ')' }, objG);
      html(g, VENT_ART);
      el('rect', { class: 'ship-hl', x: -2, y: 2, width: T + 4, height: T - 4, rx: 6, fill: 'none', stroke: '#ff7b7b', 'stroke-width': 2.5 }, g);
      el('rect', { x: 0, y: 0, width: T, height: T, fill: 'transparent' }, g);
      g.addEventListener('click', function (e) { e.stopPropagation(); if (machineCb) machineCb(v); });
    });

    // fog overlay, one shape per region
    var fogG = el('g', {}, world);
    var fogEls = regions.map(function (r) {
      var e = el('rect', { class: 'ship-fog', x: r.x0 * T, y: r.y0 * T, width: (r.x1 - r.x0 + 1) * T, height: (r.y1 - r.y0 + 1) * T, fill: '#05070f', opacity: 0 }, fogG);
      e._zone = r.zone; return e;
    });

    var blockG = el('g', {}, world);
    var fxG = el('g', {}, world);
    var actorG = el('g', {}, world);
    var actors = {};
    var fxSeen = {};

    // ---- camera: a viewBox that eases toward a target and never leaves the ship ----
    var cam = { cx: W / 2, cy: H / 2, fw: 16, fh: 10 }, target = { cx: W / 2, cy: H / 2, fw: 16, fh: 10 }, raf = 0;
    function applyCam() {
      var box = svg.getBoundingClientRect();
      var aspect = box.width > 0 && box.height > 0 ? box.width / box.height : 1.6;
      // "contain": the fw x fh tile area always fits entirely on screen
      var vw = Math.max(cam.fw * T, cam.fh * T * aspect), vh = vw / aspect;
      var halfW = vw / (2 * T), halfH = vh / (2 * T);
      var cx = W > 2 * halfW ? Math.min(Math.max(cam.cx, halfW), W - halfW) : W / 2;
      var cy = H > 2 * halfH ? Math.min(Math.max(cam.cy, halfH), H - halfH) : H / 2;
      svg.setAttribute('viewBox', (cx * T - vw / 2) + ' ' + (cy * T - vh / 2) + ' ' + vw + ' ' + vh);
    }
    var moveMs = opts.moveMs || map.moveMs || 130;
    var speed = 1000 / moveMs * 1.08;   // tiles per second, a touch faster than the server's stepping
    var meIdNow = null, last = 0;
    function loop(ts) {
      var dt = last ? Math.min(0.1, (ts - last) / 1000) : 0.016; last = ts;
      // Actors glide toward the position the server last reported, at constant speed.
      // (Snapping straight to each new tile made movement look like stop-go steps.)
      Object.keys(actors).forEach(function (id) {
        var g = actors[id], p = g._pos, t = g._tgt;
        if (!p || !t) return;
        var dx = t.x - p.x, dy = t.y - p.y, dist = Math.sqrt(dx * dx + dy * dy);
        if (g._fl && id === meIdNow) { g._moving = g._selfMoving ? ts : 0; }   // your own position is set directly by the page
        else if (dist > 4) { p.x = t.x; p.y = t.y; g._moving = 0; }               // teleport (vent, rejoin)
        else if (g._fl) {
          // other players report free positions ~20 times a second: ease toward them
          if (dist > 0.01) { var kk = 1 - Math.exp(-dt * 16); p.x += dx * kk; p.y += dy * kk; if (dist > 0.05) g._moving = ts; }
        }
        else if (dist > 0.001) {
          var step = Math.min(dist, speed * dt);
          p.x += dx / dist * step; p.y += dy / dist * step;
          g._moving = ts;
        }
        g.setAttribute('transform', 'translate(' + (p.x * T).toFixed(1) + ',' + (p.y * T - 6).toFixed(1) + ')');
        g.classList.toggle('walking', !!g._moving && ts - g._moving < 140);
        if (id === meIdNow) { target.cx = p.x + 0.5; target.cy = p.y + 0.5; }   // camera follows the smoothed position
      });
      var k = 1 - Math.exp(-dt * 10);
      cam.cx += (target.cx - cam.cx) * k; cam.cy += (target.cy - cam.cy) * k;
      cam.fw += (target.fw - cam.fw) * k; cam.fh += (target.fh - cam.fh) * k;
      applyCam();
      raf = requestAnimationFrame(loop);
    }
    applyCam(); raf = requestAnimationFrame(loop);

    svg.addEventListener('click', function (e) {
      if (!tileCb) return;
      var pt = svg.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY;
      var p = pt.matrixTransform(svg.getScreenCTM().inverse());
      var tx = Math.floor(p.x / T), ty = Math.floor(p.y / T);
      if (tx < 0 || ty < 0 || tx >= W || ty >= H) return;
      tileCb(tx, ty, rows[ty].charAt(tx));
    });

    function ensureActor(a, isMe) {
      var g = actors[a.id];
      if (g && g._color === a.color && g._name === a.name && g._role === a.role) return g;
      if (g) g.remove();
      g = el('g', { class: 'ship-actor' }, actorG);
      html(g, crewMarkup(a.color, a.name, isMe, a.role));
      g._color = a.color; g._name = a.name; g._role = a.role;
      actors[a.id] = g;
      return g;
    }

    return {
      setActors: function (list, meId) {
        var seen = {};
        list.forEach(function (a) {
          seen[a.id] = true;
          var g = ensureActor(a, a.id === meId);
          if (a.px != null) {
            g._fl = true;
            if (!g._pos) g._pos = { x: a.px, y: a.py };
            if (a.id !== meId) g._tgt = { x: a.px, y: a.py };
            else if (!g._selfInit) { g._selfInit = true; g._pos = { x: a.px, y: a.py }; g._tgt = g._pos; }
            if (a.id === meId) meIdNow = a.id;
            var fl0 = g.querySelector('.flip');
            if (fl0 && a.id !== meId) fl0.style.transform = 'scaleX(' + (a.face < 0 ? -1 : 1) + ')';
            g.style.opacity = a.ghost ? 0.45 : 1;
            if (a.id === meId) actorG.appendChild(g);
            return;
          }
          if (!g._pos) g._pos = { x: a.x, y: a.y };
          // While walking, glide toward the NEXT tile on the path (the server sends it), so the
          // character never has to stop and wait at each tile for the next update.
          g._tgt = (a.nx != null && a.nx >= 0) ? { x: a.nx, y: a.ny } : { x: a.x, y: a.y };
          if (a.id === meId) meIdNow = a.id;
          var flip = g.querySelector('.flip');
          if (flip) flip.style.transform = 'scaleX(' + (a.face < 0 ? -1 : 1) + ')';
          g.style.opacity = a.ghost ? 0.45 : 1;
          if (a.id === meId) actorG.appendChild(g); // keep yourself on top
        });
        Object.keys(actors).forEach(function (id) { if (!seen[id]) { actors[id].remove(); delete actors[id]; } });
      },
      setFog: function (visible) {
        fogEls.forEach(function (f) { f.setAttribute('opacity', (!visible || visible.indexOf(f._zone) >= 0) ? 0 : 0.7); });
      },
      // vent puffs: a soft cloud at a tile, once per event
      showFx: function (list) {
        var now = Date.now();
        (list || []).forEach(function (f) {
          var key = f.x + ',' + f.y;
          if (fxSeen[key] && now - fxSeen[key] < 1000) return;
          fxSeen[key] = now;
          var c = el('circle', { class: 'ship-puff', cx: f.x * T + T / 2, cy: f.y * T + T / 2, r: 34, fill: 'url(#g-puff)' }, fxG);
          setTimeout(function () { c.remove(); }, 1000);
        });
      },
      // machines with an active fault get a pulsing red ring
      setAlarms: function (ids) {
        machineGroups.forEach(function (g) { g._ring.setAttribute('display', (ids && ids.indexOf(g._id) >= 0) ? 'inline' : 'none'); });
      },
      // a jammed blast door across a corridor
      setBlocked: function (r) {
        blockG.innerHTML = '';
        if (!r) return;
        var x = r.x0 * T, y = r.y0 * T, w = (r.x1 - r.x0 + 1) * T, h = (r.y1 - r.y0 + 1) * T;
        el('rect', { x: x, y: y, width: w, height: h, fill: 'url(#p-hazard)', stroke: '#ff3b3b', 'stroke-width': 3 }, blockG);
        var t = el('text', { x: x + w / 2, y: y + h / 2 + 4, 'text-anchor': 'middle', fill: '#fff', 'font-size': 11, 'font-weight': 800, 'font-family': 'system-ui,sans-serif', stroke: '#3a1014', 'stroke-width': 3, 'paint-order': 'stroke' }, blockG);
        t.textContent = 'BLAST DOOR';
      },
      // your own character: the page moves it directly, no waiting for the server
      setSelf: function (x, y, face, moving) {
        var g = meIdNow && actors[meIdNow]; if (!g) return;
        g._pos = { x: x, y: y }; g._tgt = g._pos; g._selfMoving = !!moving;
        var fl = g.querySelector('.flip'); if (fl) fl.style.transform = 'scaleX(' + (face < 0 ? -1 : 1) + ')';
      },
      follow: function (x, y) { if (!meIdNow) { target.cx = x + 0.5; target.cy = y + 0.5; } },
      setFit: function (fw, fh) { target.fw = fw; target.fh = fh; if (fw >= W) { target.cx = W / 2; target.cy = H / 2; } },
      onTile: function (cb) { tileCb = cb; },
      onMachine: function (cb) { machineCb = cb; },
      destroy: function () { cancelAnimationFrame(raf); svg.innerHTML = ''; }
    };
  }

  window.ShipMap = { create: create, COLORS: COLORS, TILE: T };
})();
